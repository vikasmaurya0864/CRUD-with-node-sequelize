const express = require('express');
const router = express.Router();
const controllers = require('../controllers/userControllers');
/* GET home page. */
router.post('/users',controllers.createData);
router.get('/users',controllers.getData);
router.put('/users/:id',controllers.updateData);
router.delete('/users/:id',controllers.deleteData);

module.exports = router;
